<?php

$username="";
$password="";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	
	$var=$_POST;

	if (empty($var["username"]))  {
        	echo "Username nije unesen.";
		
    		}
	else if (empty($var["password"]))  {
        	echo "Niste unijeli lozinku.";
		
    		}
	else {
		$username= $var
["username"];
		$password= $var
["password"];
	
		provjera($username,$password);
	}
}


function provjera($username, $password) {
	

	$datoteka=simplexml_load_file("users.xml");
	
	
	foreach ($datoteka->user as $usr) {
  	 	$ime_b = $usr->username;
		$lozinka_b = $usr->password;
		$ime_baza=$usr->ime;
		$prezime_baza=$usr->prezime;
		if($ime_b==$username){
			if($lozinka_b == $password){
				header("Location: htmls/korisnik.html");
				return;
				}
			else{
				echo "Netocna lozinka";
				return;
				}
			}
		}
		
	echo "Korisnik ne postoji.";
	return;
}
?>

<html>
<head>
<title>Login</title>

</head>
<body style="background-image: url('green.png');background-repeat: no-repeat;background-attachment: fixed;background-size: 100% 100%;height: 100%;
    margin: 0;
    padding:0;">
<header style="margin-top:200px;text-align:center;font-family:tahoma;color:white;font-size:40px;font-weight:bold">Priroda i društvo</header>
<form action="" method="post">

<table style="margin-left: auto;margin-right: auto;margin-top:20px;background-color:no;">
<tr>
<td>

</td>
<td>

<td>
</tr>
<tr>
<td>
<tr>
<td>
<label></label>
</td>
<td>
<label></label>
<td>
</tr>
</td>
<td>

<td>
</tr>

<tr>
<td>
<label>Korisnicki racun :</label>
</td>
<td>
<input id="name" name="username" type="text">
<td>
</tr>


<tr>
<td>
<label>Lozinka :</label>
</td>
<td>
<input id="password" name="password" type="password">
<td>
</tr>

<tr>
<td>
<input name="submit" type="submit" value=" Korisnik " style="background-color:white;height:40px;width:100px;margin-left:50px;margin-right: auto;margin-top:20%;margin-bottom:20%;box-shadow: 2px 3px">
</td>
<td>
<button name="submit1" type="submit" style="background-color:white;height:40px;width:100px;margin-left:50px;margin-right: auto;margin-top:20%;margin-bottom:20%;box-shadow: 2px 3px"><a href="htmls/guest.html" style="color:black;text-decoration:none">Guest</a></button>
</td>

<td>


</table>
</form>

</body>
</html>